##CSS language plugin for Light Table

The official CSS language plugin for Light Table

###License

Copyright (C) 2013 Kodowa Inc.

Distributed under the GPLv3, see license.md for the full text.