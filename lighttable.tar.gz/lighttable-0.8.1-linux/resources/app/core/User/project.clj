(defproject user "0.0.1"
  :dependencies [[org.clojure/clojure "1.6.0"]])
