##Changes

###0.0.2
* ADDED: `Paredit: Unwrap parent` command
