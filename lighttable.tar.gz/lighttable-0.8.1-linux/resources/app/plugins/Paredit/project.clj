(defproject com.lighttable/paredit "0.0.4"
  :description "paredit plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
