# Runner

This project is just used to provide an uberjar that can be run to start up the clojure process. It injects lein-light-nrepl into that process and then just starts a repl.