(ns user
  (:require [clojure.repl :refer :all]))
