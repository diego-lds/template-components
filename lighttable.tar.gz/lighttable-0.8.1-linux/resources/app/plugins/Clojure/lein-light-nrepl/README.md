# lein-light-nrepl

lein-light-nrepl is the nrepl-based client for Light Table's clojure and clojurescript evaluation. Basically everything that requires the JVM will be found in this project.